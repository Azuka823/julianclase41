Referencia de la maestra 1 - C42 - 1:4
